


DATA_FILE="packages.csv"
STATUS_MAP = { 
    1: "Booked",
    2: "In Transit",
    3: "Out for delivery",
    4: "Delivered"
    }
